package co.edu.unipiloto.ws.testws.services;

import co.edu.unipiloto.ws.testws.entidad.Person;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("service")
public class Service {

    private static Map<Integer, Person> persons = new HashMap<>();

    static {
        for (int i = 0; i < 10; i++) {
            Person person = new Person();
            int id = i + 1;
            person.setId(id);
            person.setFullName("My wonderful Person " + id);
            int edad = new Random().nextInt(40) + 1;
            person.setAge(edad);
            person.setSalary(id);
            persons.put(id, person);
        }
    }

    @GET
    @Path("/getPersonByIdXML/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Person getPersonByIdXML(@PathParam("id") int id) {
        return persons.get(id);
    }

    @GET
    @Path("/getPersonByIdJson/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getPersonByIdJson(@PathParam("id") int id) {
        return persons.get(id);
    }

    @GET
    @Path("/getAllPersonsInXML")
    @Produces(MediaType.APPLICATION_XML)
    public List<Person> getAllPersonsInXML() {
        return new ArrayList<Person>(persons.values());
    }

    @GET
    @Path("/getAllPersonsInJson")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Person> getAllPersonsInJson() {
        return new ArrayList<Person>(persons.values());
    }

    @POST
    @Path("/addPersonInJson")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Person addPersonInJson(Person person) {
        System.out.println(person.getId());
        person.setSalary(person.getAge());
        persons.put(new Integer(person.getId()), person);
        return person;
    }

    @GET
    @Path("/getAvarageSalaryInXML")
    @Produces(MediaType.APPLICATION_XML)
    public SalaryResponse getAvarageSalaryInXML() {
        return new SalaryResponse(salarioPromedio());
    }

    @GET
    @Path("/getSumaSalaryInJson")
    @Produces(MediaType.APPLICATION_JSON)
    public int getSumaSalaryInJson() {
        return sumaSalarios();
    }
    
    @POST
    @Path("/addNewPersonInJson")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Person addNewPersonInJson(Person person) {
        System.out.println(person.getId());
        person.setSalary(person.getAge());
        person.setId(persons.size() + 1);
        persons.put(persons.size() + 1, person);
        return person;
    }

    public double salarioPromedio() {
        if (persons.isEmpty()) {
            return 0;
        }
        int suma = 0;
        for (Person person : persons.values()) {
            suma += person.getSalary();
        }
        return (double) suma / persons.size();
    }

    public int sumaSalarios() {
        int suma = 0;
        for (Person person : persons.values()) {
            suma += person.getSalary();
        }
        return suma;
    }

}
