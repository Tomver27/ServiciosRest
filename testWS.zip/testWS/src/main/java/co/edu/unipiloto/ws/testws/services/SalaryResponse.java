/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.ws.testws.services;

import javax.xml.bind.annotation.XmlRootElement;
/**
 *
 * @author Tomás Vera
 */ 
@XmlRootElement
public class SalaryResponse {
    private double averageSalary;

    public SalaryResponse() {}

    public SalaryResponse(double averageSalary) {
        this.averageSalary = averageSalary;
    }

    public double getAverageSalary() {
        return averageSalary;
    }

    public void setAverageSalary(double averageSalary) {
        this.averageSalary = averageSalary;
    }
}

